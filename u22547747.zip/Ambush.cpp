#include "Ambush.h"
#include <iostream>

void Ambush::engage() {
	std::cout << "Laying an ambush!" << std::endl;
}
