#ifndef OPENFIELDINFANTRY_H
#define OPENFIELDINFANTRY_H
#include "Infantry.h"

class OpenFieldInfantry : public Infantry {


public:
	void move();

	void attack(int legionSize);
};

#endif
