#include "LegionUnit.h"
#include <stdexcept>


void LegionUnit::add(LegionUnit* component) {
}

void LegionUnit::remove(LegionUnit* component) {
}

LegionUnit::~LegionUnit()
{
}
