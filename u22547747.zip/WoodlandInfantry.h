#ifndef WOODLANDINFANTRY_H
#define WOODLANDINFANTRY_H
#include "Infantry.h"

class WoodlandInfantry : public Infantry {


public:
	void move();

	void attack(int legionSize);
};

#endif
