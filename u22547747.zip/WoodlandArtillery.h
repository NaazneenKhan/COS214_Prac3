#ifndef WOODLANDARTILLERY_H
#define WOODLANDARTILLERY_H
#include "Artillery.h"

class WoodlandArtillery : public Artillery {


public:
	void move();

	void attack(int legionSize);
};

#endif
