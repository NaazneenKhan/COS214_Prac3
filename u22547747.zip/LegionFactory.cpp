#include "LegionFactory.h"


Infantry* LegionFactory::createInfantry() {
	// TODO - implement LegionFactory::virtual createInfantry
	throw "Not yet implemented";
}

Cavalry* LegionFactory::createCavalry() {
	// TODO - implement LegionFactory::virtual createCavalry
	throw "Not yet implemented";
}

Artillery* LegionFactory::createArtillery() {
	// TODO - implement LegionFactory::virtual createArtillery
	throw "Not yet implemented";
}

LegionFactory::~LegionFactory()
{
}
