#ifndef RIVERBANKINFANTRY_H
#define RIVERBANKINFANTRY_H
#include "Infantry.h"

class RiverbankInfantry : public Infantry {


public:
	void move();

	void attack(int legionSize);
};

#endif
