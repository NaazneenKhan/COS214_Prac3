#include "Flanking.h"
#include <iostream>


void Flanking::engage()
{
    std::cout << "Executing flanking maneuver!" << std::endl;
}
