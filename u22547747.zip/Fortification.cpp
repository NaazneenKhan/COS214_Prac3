#include "Fortification.h"
#include <iostream>

void Fortification::engage() {
	std::cout << "Fortifying positions!" << std::endl;
}
