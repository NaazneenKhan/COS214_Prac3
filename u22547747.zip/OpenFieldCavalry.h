#ifndef OPENFIELDCAVALRY_H
#define OPENFIELDCAVALRY_H
#include "Cavalry.h"

class OpenFieldCavalry : public Cavalry {


public:
	void move();

	void attack(int legionSize);
};

#endif
